#ifndef cTimeSeries_h
#define cTimeSeries_h

#include <iostream>
#include <string>


class cTimeSeries
{
public:
	std::string theName;
	int theSize;
	double *theData;


	cTimeSeries(double *theData, int theSize);
	~cTimeSeries();
	double mean();
	double std();
	void plot();

	
};


#endif

