#pragma once
class cAR
{
};

