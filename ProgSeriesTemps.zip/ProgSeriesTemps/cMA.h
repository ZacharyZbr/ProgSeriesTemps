#pragma once
class cMA
{
};

