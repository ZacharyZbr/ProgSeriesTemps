#pragma once
#include <iostream>

class cDistribution
{
public:
	
	
};

