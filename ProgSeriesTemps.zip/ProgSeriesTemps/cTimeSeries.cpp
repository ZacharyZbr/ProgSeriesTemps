#include "cTimeSeries.h"

cTimeSeries::cTimeSeries(double *theData, int theSize){
	this->theData = theData;
	this->theSize = theSize;
}

double cTimeSeries::mean() {
	return 0;

}

double cTimeSeries::std() {
	return 0;
}