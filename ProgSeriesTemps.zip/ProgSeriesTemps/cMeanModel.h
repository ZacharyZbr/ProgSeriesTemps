#ifndef cMeanModel_h
#define cMeanModel_h

#include <iostream>
#include "cTimeSeries.h"

class cMeanModel: public cTimeSeries
{
public:


};

#endif